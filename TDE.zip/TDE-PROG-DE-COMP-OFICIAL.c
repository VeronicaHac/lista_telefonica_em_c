#include <stdio.h>
#include <string.h>


int main() {

    int op;
    char nome[21] = {'\0'};
    char nomecomp2[21] = {'\0'};
    char nomecomp3[21] = {'\0'};
    char telefone [12] = {0};
    int i;
    int cont = 0;
    int cont2 = 0;

    while (op != 4){
        printf("[1] Cadastrar telefone\n");
        printf("[2] Consultar telefone\n");
        printf("[3] Excluir telefone\n");
        printf("[4] Sair do Menu\n");
        printf("-------- Digite a opcao desejada --------\n");

        scanf("%i",&op);


        if(op != 4){

                switch(op){
                    case 1:
                        printf("NOVO CONTATO\n");

                        printf("Digite o nome: ");
                        scanf("%s", nome);
                        printf("\nDigite o telefone: ");
                        scanf("%s", telefone);


                        while(telefone == 0 || nome == 0){
                            printf("Nome ou Telefone em branco, por favor digite novamente.\n\n");
                            printf("Digite o nome: ");
                            scanf("%s", nome);
                            printf("\nDigite o telefone: ");
                            scanf("%s", telefone);
                        }

                            printf("\nTelefone cadastrado com sucesso: %s %s\n\n\n", nome, telefone);


                        break;
                    case 2:
                        printf("Digite um nome: ");
                        scanf("%s", nomecomp2);

                        for(i=0;i<strlen(nomecomp2);i++){
                           if(nomecomp2[i] == nome[i]){
                                cont2 ++;
                             }
                        }

                        if(cont2 >= strlen(nome)){
                             printf("\nContato Cadastrado %s %s!\n\n\n",nome,telefone);
                             cont2 = 0;

                        } else {
                            printf("Contato %s nao cadastrado\n\n\n", nomecomp2);
                            cont2 = 0;
                        }

                        break;
                    case 3:
                        printf("Digite um nome: ");
                        scanf("%20s", nomecomp3);

                        for(i=0;i<strlen(nomecomp3);i++){
                           if(nomecomp3[i] == nome[i]){
                                cont ++;
                             }
                        }

                        if(cont >= strlen(nome)){
                             printf("\nContato Excluido %s %s!\n\n\n",nome,telefone);
                             cont = 0;

                        } else {
                            printf("Contato %s nao encontrado\n\n\n", nomecomp3);
                            cont = 0;
                        }






                        break;

                    default:
                        printf("Opcao invalida, por favor digite uma opcao valida\n\n");

                }

        }else {
            printf("Encerrando o programa, Tchau!\n");

        }

    }








return 0;
}
